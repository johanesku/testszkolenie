COURSE ARCHIVER & TRANSCRIBER 4.7.0

Kliknij dwukrotnie:
01_INSTALUJ.cmd

Co nowego w 4.7.0:
- Inkrementalna budowa: komponenty bez zmian sa przywracane z pamieci
  podrecznej, wiec kolejne instalacje trwaja sekundy zamiast dziesiatek minut.
- Jesli Windows (Smart App Control) zablokuje instalator, aplikacja wdraza sie
  w trybie przenosnym i pokazuje instrukcje.
- Ciemny interfejs z lista profili, zywa lista materialow i widokiem Archiwum.
- Widoczny status ZALOGOWANO i przycisk ZROB WSZYSTKO (caly proces jednym klikiem).

Pelna historia zmian: package/CHANGELOG.md

W razie bledu:
%LOCALAPPDATA%\CourseArchiverInstaller\INSTALL_LOG.txt

Finalny instalator po sukcesie:
%USERPROFILE%\Downloads\CourseArchiver_Setup_4.7.0.exe
