COURSE ARCHIVER & TRANSCRIBER 4.6.0

Kliknij dwukrotnie:
01_INSTALUJ.cmd

Co nowego w 4.6.0:
- Po udanym logowaniu aplikacja wyraznie pokazuje status ZALOGOWANO.
- Mozesz wlaczyc automatyczne przejscie do skanowania kursu zaraz po logowaniu.
- Nowy przycisk ZROB WSZYSTKO wykonuje caly proces jednym kliknieciem.
- Pasek postepu pokazuje etap: logowanie, skanowanie, pobieranie, transkrypcja.

Uwaga: ta wersja zawsze buduje aplikacje od nowa, poniewaz zmienil sie kod
GUI i agenta. Pliki EXE z wersji 4.4/4.5 nie sa juz wykorzystywane ponownie.

W razie bledu:
%LOCALAPPDATA%\CourseArchiverInstaller\INSTALL_LOG.txt

Finalny instalator po sukcesie:
%USERPROFILE%\Downloads\CourseArchiver_Setup_4.6.0.exe
